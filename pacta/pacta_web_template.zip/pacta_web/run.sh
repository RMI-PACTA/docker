#! /bin/bash

# docker load --input 2dii_pacta.tar.gz

portfolio_name="TestPortfolio_Input"
working_dir="$(pwd)"/working_dir
user_results="$(pwd)"/user_results/4

docker run --rm -ti \
  --memory="4g" \
  --mount type=bind,source="$working_dir",target=/bound/working_dir \
  --mount type=bind,source="$user_results",target=/user_results \
  2dii_pacta \
  /bound/bin/run-r-scripts "$portfolio_name"
